#include "Architecture.h"

/*
#ifdef _WIN64

const WCHAR Architecture::NAME[] = L"x64";

const WCHAR Architecture::PRINTF_DWORD_PTR[]      = L"%I64X";
const WCHAR Architecture::PRINTF_DWORD_PTR_FULL[] = L"%016I64X";
const WCHAR Architecture::PRINTF_DWORD_PTR_HALF[] = L"%08I64X";
const WCHAR Architecture::PRINTF_INTEGER[]        = L"%I64u";

#else

const WCHAR Architecture::NAME[] = L"x86";

const WCHAR Architecture::PRINTF_DWORD_PTR[]      = L"%X";
const WCHAR Architecture::PRINTF_DWORD_PTR_FULL[] = L"%08X";
const WCHAR Architecture::PRINTF_DWORD_PTR_HALF[] = L"%08X";
const WCHAR Architecture::PRINTF_INTEGER[]        = L"%u";

#endif
*/
